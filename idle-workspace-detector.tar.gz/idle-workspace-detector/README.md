# idle-workspace-detector
Checks for idle workspaces and notifies users

## How it works
main.py should be run as a scheduled job every 30 minutes, with the proper smtp and MongoDB credentials. The code:

- Collects all running workspaces.
- Checks data/allowlist.csv to see if a workspace should be ignored (see addToAllowlist.py below)
- If not, the last 30 minutes of usage data is checked to see if the workspace is idle.
- Idle workspaces are detected by utilizing CPU and memory usage statistics, which are only available for the past 1/2 hour. If the standard deviation of CPU and memory use is below a specified threshold and the avrage CPU usage is also below a specified percentage, the workspace is considered idle.
-- Note: The Domino REST API only returns for the last 30 minutes.
- If a workspace is considered idle, it is added or incremented by 30 minutes in data/idle_workspaces.csv (we use 30 because we really can't tell exactly when idling began).
- If a workspace has been stopped by the user between runs of this job, it is not considered idle anymore.
- All idle workspaces are then checked to see if they should receive an email (if running idle for `warning_interval_hours` or more hours) or shutdown after `shutdown_after_hours` hours.

## Configuration
Modify the config.yaml file:
```
domino_domain: opendatasciencelab.jnj.com
notify:
  admins: "svelez1@its.jnj.com,cchu5@its.jnj.com"
  smtp_host: "smtp.na.jnj.com"
  smtp_port: 25
  from_email: "opendatasciencelab-noreply@its.jnj.com"
idle:
  cpu_std_deviation: 0.2
  average_cpu_limit_pct: 30
  mem_std_deviation: 0.03
  warning_interval_hours: 4
  shutdown_after_hours: 12
```
- **domino_domain**: The domain name of the Domino cluster
- **admins**: Comma separated list of admins to whom notifications will be sent in dry run mode
- **smtp_host, smtp_port**: Could be SES or internal
- **from_email**: The sender who appears in outgoing mail to users
- **cpu_std_deviation**: Threshold for CPU utilization standard deviation (< 1)
- **average_cpu_limit_pct**: Threshold percentage for CPU utilization (< 100))
- **mem_std_deviation**: Threshold for memory utilization standard deviation (< 1)
- **warning_interval_hours**: Interval used to send warning emails (integer)
- **shutdown_after_hours**: Stop workspace after these many hours (integer < warning_interval_hours)

## How to run it
By default the code runs in 'dry run' mode and does not stop workspaces or warn users. Instead, the messages are sent to the **admins** configured above. To actually warn users, use the `--live-run` flag
```
python main.py [--live-run]
```
## Testing it
Every run accumulates 1/2 hour in the data/idle_workspaces.csv file, so running the code 4 times will simulate a 2 hour run. You can set the **warning_interval_hours** to 2 and **shutdown_after_hours** to 4. Running the code 4 times should send out warnings and running it 4 more times should stop the idle workspaces. Once the basic functionality is working, you can stop identified idle workspaces and make sure no more warnings are sent.

## Permitting some user-project combinations to idle away
```
python addToAllowlist.py <login-user-id> <project-name>

e.g.
python addToAllowlist.py integration-test quick-start
```
