import requests
from idle_wksp_base import IdleWorkspacesBase


class IdleWorkspacesActive(IdleWorkspacesBase):
    def __init__(self, config):
        super().__init__(config)
        self.dry_run_prefix = ""

    # Shutdown a workspace using the Domino API and send an email alerting
    # the user.
    def shutdown_workspace(self, workspace):
        url = "{}/v4/workspace/project/{}/workspace/{}/stop".format(
            self.domino_api_host,
            workspace["ProjectId"],
            workspace["WorkspaceId"],
        )
        response = requests.post(url, headers=self.header)
        return response.status_code == 200

    def get_recipient_email(self, user):
        return user["email"]
