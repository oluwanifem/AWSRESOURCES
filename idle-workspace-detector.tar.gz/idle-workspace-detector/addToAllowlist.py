import csv
import sys
import os
from pymongo import MongoClient
from pathlib import Path
import pandas as pd


# Create the allowlist csv if it does not exist.
def init_allow_csv():
    with open("data/allowlist.csv", "w") as csvfile:
        writer = csv.writer(csvfile, delimiter=",")
        writer.writerow(["UserId", "ProjectId"])


if not Path("data").is_dir():
    os.mkdir("data")

if not Path("data/allowlist.csv").is_file():
    init_allow_csv()

# Collect username and project name from arguments
username = sys.argv[1]

project_name = sys.argv[2]

# Mongo Variables
user = "<MONGO_USER>"
password = "<MONGO_PASSWORD>"
platform_namespace = "<DOMINO_PLATFORM_NAMESPACE>"

# Create the MongoDB Client
client = MongoClient(
    "mongodb://mongodb-replicaset.{}.svc.cluster.local:27017".format(
        platform_namespace
    ),
    username=user,
    password=password,
    authSource="domino",
    authMechanism="SCRAM-SHA-1",
)

db = client["domino"]

# Get the project and user IDs
project = pd.DataFrame.from_records(
    list(db.projects.find({"name": project_name}))
)
user = pd.DataFrame.from_records(list(db.users.find({"loginId.id": username})))

# Add project ID and user ID to allowlist if it is not already there.
allowlist = pd.read_csv("data/allowlist.csv")
if (
    len(
        allowlist.loc[
            (allowlist["ProjectId"] == str(project))
            & (allowlist["UserId"] == str(user))
        ]
    )
    > 0
):
    exit(0)

with open("data/allowlist.csv", "a") as f:
    writer = csv.writer(f)
    writer.writerow([user["_id"][0], project["_id"][0]])
