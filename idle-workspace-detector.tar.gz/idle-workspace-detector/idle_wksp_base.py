import csv
import os
import pandas as pd
from pathlib import Path
import requests
from pymongo import MongoClient
import notifications
import logging

# Mongo Variables
platform_namespace = "domino-platform"
logger = logging.getLogger("idle_workspaces")

class IdleWorkspacesBase:
    def __init__(self, config):
        # Create the MongoDB client
        client = MongoClient(
            "mongodb://mongodb-replicaset.{}.svc.cluster.local:27017".format(
                platform_namespace
            ),
            username=os.environ["MONGODB_USERNAME"],
            password=os.environ["MONGODB_PASSWORD"],
            authSource="admin",
            authMechanism="SCRAM-SHA-256",
        )

        self.db = client["domino"]
        self.config = config
        # Information for Domino API calls
        self.header = {"X-Domino-Api-Key": os.environ["DOMINO_USER_API_KEY"]}
        self.domino_api_host = os.environ["DOMINO_API_HOST"]
        self.dry_run_prefix = "DRY RUN - "

    # Check if the last 30 minutes of usage classify the workspace as idle.
    def parse_usage(self, response):
        entries = pd.DataFrame(response.json()["snapshots"])
        if "cpu" not in entries.columns or "memory" not in entries.columns:
            return False
        cpu_sd = entries["cpu"].std()
        cpu_avg = entries["cpu"].mean() * 100.0
        memory_sd = entries["memory"].std() / 1000000000
        logger.debug(
            "{}:{}, {}:{}, {},{}".format(
                cpu_sd,
                self.config["idle"]["cpu_std_deviation"],
                memory_sd,
                self.config["idle"]["mem_std_deviation"],
                cpu_avg,
                self.config["idle"]["average_cpu_limit_pct"],
            )
        )
        return (
            cpu_sd < self.config["idle"]["cpu_std_deviation"]
            and memory_sd < self.config["idle"]["mem_std_deviation"]
            and cpu_avg < self.config["idle"]["average_cpu_limit_pct"]
        )

    # Removes a workspace from the idle_workspaces csv tracker.
    def remove_if_no_longer_idle(self, session):
        idle_workspaces = pd.read_csv("data/idle_workspaces.csv")
        idle_workspaces = idle_workspaces[idle_workspaces.SessionId != session]
        idle_workspaces.to_csv(
            "data/idle_workspaces.csv", sep=",", index=False
        )

    # When an idle workspace is found, add or increment the idle_workspace
    # tracker.
    def handle_idle_workspace(self, workspace, session):
        idle_workspaces = pd.read_csv("data/idle_workspaces.csv")
        if session in set(idle_workspaces["SessionId"]):
            current_idle = idle_workspaces.loc[
                idle_workspaces["SessionId"] == session
            ]["IdleTime"].values[0]
            idle_workspaces.loc[
                idle_workspaces["SessionId"] == session, "IdleTime"
            ] = (current_idle + 0.5)
        else:
            idle_workspaces.loc[len(idle_workspaces.index)] = [
                workspace["_id"],
                workspace["name"],
                workspace["ownerId"],
                session,
                workspace["projectId"],
                0.5,
            ]
        idle_workspaces.to_csv(
            "data/idle_workspaces.csv", sep=",", index=False
        )

    # Create the idle_workspaces csv if it does not exist.
    def init_idle_csv(self):
        with open("data/idle_workspaces.csv", "w") as csvfile:
            writer = csv.writer(csvfile, delimiter=",")
            writer.writerow(
                [
                    "WorkspaceId",
                    "WorkspaceName",
                    "OwnerId",
                    "SessionId",
                    "ProjectId",
                    "IdleTime",
                ]
            )

    # Create the allowlist csv if it down not exist.
    def init_allow_csv(self):
        with open("data/allowlist.csv", "w") as csvfile:
            writer = csv.writer(csvfile, delimiter=",")
            writer.writerow(["UserId", "ProjectId"])

    def init_all(self):
        if not Path("data").is_dir():
            os.mkdir("data")

        if not Path("data/idle_workspaces.csv").is_file():
            self.init_idle_csv()

        if not Path("data/allowlist.csv").is_file():
            self.init_allow_csv()

    def remove_stopped_workspaces_from_idle_list(
        self, stopped_workspaces: pd.DataFrame
    ):
        for _, workspace in stopped_workspaces.iterrows():
            session_url = (
                "{}/v4/workspace/project/{}/workspace/{}/sessions".format(
                    self.domino_api_host,
                    workspace["projectId"],
                    workspace["_id"],
                )
            )
            try:
                sessions = requests.get(session_url, headers=self.header)
            except requests.exceptions.ConnectionError:
                continue
            sessions = pd.DataFrame.from_records(sessions.json())
            sessions["start"] = sessions["start"].apply(lambda x: x["time"])
            latest_session = sessions[sessions.start == sessions.start.max()][
                "id"
            ][0]
            self.remove_if_no_longer_idle(latest_session)

    def get_recipient_email(self, user):
        return self.config["notify"]["admins"]

    def shutdown_or_warn(self):
        projects = pd.DataFrame.from_records(list(self.db.projects.find()))
        users = pd.DataFrame.from_records(list(self.db.users.find()))
        projects["_id"] = projects["_id"].apply(lambda x: str(x))
        users["_id"] = users["_id"].apply(lambda x: str(x))
        idle_workspaces = pd.read_csv("data/idle_workspaces.csv")
        idle_workspaces = idle_workspaces[
            idle_workspaces["IdleTime"]
            >= self.config["idle"]["warning_interval_hours"]
        ]
        for idx, workspace in idle_workspaces.iterrows():
            project_name = projects.loc[
                projects["_id"] == workspace["ProjectId"]
            ].iloc[0]["name"]
            user = users.loc[users["_id"] == workspace["OwnerId"]].iloc[0]
            username = user["loginId"]["id"]
            to_addr = self.get_recipient_email(user)
            if (
                workspace["IdleTime"]
                >= self.config["idle"]["shutdown_after_hours"]
            ):
                if self.shutdown_workspace(workspace):
                    email = notifications.format_stopped_email(
                        self.config,
                        workspace["WorkspaceName"],
                        project_name,
                        username,
                    )
                    email_subject = (
                        self.dry_run_prefix + "Idle Workspace Shutdown"
                    )
                    notifications.send_email(
                        self.config, to_addr, email, email_subject
                    )

                    idle_workspaces.drop(idx, inplace=True)
                    idle_workspaces.to_csv(
                        "data/idle_workspaces.csv", sep=",", index=False
                    )
            elif (
                workspace["IdleTime"]
                % self.config["idle"]["warning_interval_hours"]
                == 0
            ):
                email = notifications.format_warning_email(
                    self.config,
                    workspace["WorkspaceName"],
                    project_name,
                    username,
                )
                email_subject = (
                    self.dry_run_prefix + "Idle Running Workspace Reminder"
                )
                notifications.send_email(
                    self.config, to_addr, email, email_subject
                )

    def filter_idle_allowed(self, workspaces: pd.DataFrame):
        allowlist = pd.read_csv("data/allowlist.csv")
        allowed = workspaces.merge(
            allowlist,
            how="left",
            left_on=["projectId", "ownerId"],
            right_on=["ProjectId", "UserId"],
            suffixes=(),
            indicator=True,
        )
        idle_not_allowed = allowed.loc[allowed["_merge"] == "left_only"]
        idle_not_allowed = idle_not_allowed.drop(
            columns=["_merge", "UserId", "ProjectId"]
        )
        return idle_not_allowed

    def check_and_update_idle_wksp(self, workspaces: pd.DataFrame):
        for _, workspace in workspaces.iterrows():
            session_url = (
                "{}/v4/workspace/project/{}/workspace/{}/sessions".format(
                    self.domino_api_host,
                    workspace["projectId"],
                    workspace["_id"],
                )
            )
            sessions = requests.get(session_url, headers=self.header)
            sessions = pd.DataFrame.from_records(sessions.json())
            sessions["start"] = sessions["start"].apply(lambda x: x["time"])
            latest_session = sessions[sessions.start == sessions.start.max()][
                "id"
            ][0]
            url = "{}/v4/workspace/{}/usage?projectId={}".format(
                self.domino_api_host, latest_session, workspace["projectId"]
            )
            usage = requests.get(url, headers=self.header)
            if usage.status_code != 200:
                continue
            if self.parse_usage(usage):
                self.handle_idle_workspace(workspace, latest_session)
            else:
                self.remove_if_no_longer_idle(latest_session)

    def process_idle_workspaces(self):
        self.init_all()
        workspaces = pd.DataFrame.from_records(list(self.db.workspace.find()))
        stopped_workspaces = workspaces[workspaces["state"] == "Stopped"]
        workspaces = workspaces[workspaces["state"] == "Started"]
        workspaces["projectId"] = workspaces["projectId"].apply(
            lambda x: str(x)
        )
        workspaces["ownerId"] = workspaces["ownerId"].apply(lambda x: str(x))

        self.remove_stopped_workspaces_from_idle_list(stopped_workspaces)

        # Checks if workspace is in the allowlist, then checks usage and adds
        # to idle_workspaces csv accordingly.
        workspaces = self.filter_idle_allowed(workspaces)
        self.check_and_update_idle_wksp(workspaces)

        # Check idle workspaces and address accordingly.
        self.shutdown_or_warn()

    def shutdown_workspace(self, workspace):
        return True
